# -*- coding: utf-8 -*-
import web, json, OrderClass

class Order:
	"""预定信息"""
	orderId = -1
	orderRoomIds = []
	orderFoodIds = []
	orderPersonMaxCount = -1
	orderName=""
	orderRemark=""
		

urls = (
    "/", "index",
    "/servers/testapi", "testapi", #测试接口
    "/servers/register", "register", #注册
    "/servers/login", "login",#登陆
    "/servers/roomlist", "roomlist",#单间列表
    "/servers/foodlist", "foodlist",#菜品列表
    "/servers/orderroom", "orderroom",#预定房间
)
app = web.application(urls, globals())
db = web.database(dbn = "sqlite", db = "./db.sqlite")

OrderInfoList = []

class index:
    def GET(self):
        return "<html><h1>Welcome to IOrder Server designed by Rendl based on webpy.</h1></html>"

class testapi:
    def GET(self):
        data = web.input()
        name = data.name
        return "hello, " + name + '!'
    def POST(self):
    	data = web.data()
    	print data
    	return "Server get data" + data + "!"

class register:
	"""注册"""
	def POST(self):
		web.header('Content-Type', 'application/json') 
		try:			
			jsonData = json.loads(web.data())
			print jsonData["name"] + "----" + jsonData["password"]
			#待加判断
			userList = db.select("users",  where="name=$name", vars={"name":jsonData["name"]}).list()
			if len(userList) != 0 :#已被注册
				return json.dumps({'status':"-2"})
			db.insert(  "users",
						name=jsonData["name"],
						pwd=jsonData["password"])
		except Exception, e:
			print "Add user error"
			return json.dumps({'status':"-1"})

		return json.dumps({'status':"0"})

class login:
	"""登陆"""
	def POST(self):
		web.header('Content-Type', 'application/json') 
		try:
			jsonData = json.loads(web.data())
			#待判断
			userList = db.select("users",  where="name=$name and pwd=$pwd", vars={"name":jsonData["name"], "pwd":jsonData["password"]}).list()			
			if len(userList) == 0:#没注册
				return  json.dumps({'status':"-2"})
		except Exception, e:
			print e
			return  json.dumps({'status':"-1"})
		return json.dumps({'status':"0", "id":str(userList[0]["id"])})


class roomlist:
	"""房间信息"""
	def POST(self):
		web.header('Content-Type', 'application/json') 
		try:
			print web.data()
			roomlist = db.select('rooms').list()
			print len(roomlist)	
		except Exception, e:
			print e
			return  json.dumps({'status':"-1"})
		return json.dumps({'status':"0", "count":str(len(roomlist)), "rooms":roomlist}) 
		
class orderroom:
	"""预定房间"""
	def POST(self):
		web.header('Content-Type', 'application/json') 
		try:
			jsonData = json.loads(web.data())
			o = Order()
			o.orderId = len(OrderInfoList)
			for item in jsonData["orderroomids"]:
				o.orderRoomIds.append(item["id"])
			for item in jsonData["orderfoodids"]:
				o.orderFoodIds.append(item["id"])			
			o.orderPersonMaxCount = jsonData["orderpersoncount"]
			o.orderName = jsonData["orderremark"]
			OrderInfoList.append(o)
		except Exception, e:
			print e
			return  json.dumps({'status':"-1"})
		return json.dumps({'status':"1", 'orderid':str(o.orderId)})

class foodlist:
	"""菜品列表"""
	def GET(self):
		foodArray = []
		try:
			foodArray = db.select('food').list()
			print foodArray
		except Exception, e:
			print e
			return  json.dumps({'status':"-1"})
		return json.dumps({'status':"0", "foodlist":foodArray})		
		

if __name__ == "__main__":
	app.run()

